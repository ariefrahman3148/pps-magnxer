public class Jobs {

	private int jobID;
	private int jobDesc;
	private int jobStatus;
	private int postedBy;
	private int companyID;

	public void createJob() {
		// TODO - implement Jobs.createJob
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jobID
	 */
	public void updateJob(int jobID) {
		// TODO - implement Jobs.updateJob
		throw new UnsupportedOperationException();
	}

}