public class Talent extends User {

	private int talentID;
	private int lastEducation;
	private int expectedSalary;
	private int resumeDoc;
	private int legalDoc;

	public void addExperience() {
		// TODO - implement Talent.addExperience
		throw new UnsupportedOperationException();
	}

}