public class Company extends User {

	private int companyID;
	private int country;
	private int state;
	private int city;
	private int address;
	private int postalCode;

}