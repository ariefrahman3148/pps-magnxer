public class JobApplication {

	private string jobAppStatus;
	private int jobRecID;
	private int talentID;
	private int jobAppTimestamp;
	private int jobAppID;

	/**
	 * 
	 * @param jobRecID
	 * @param talentID
	 */
	public void addJobApp(int jobRecID, int talentID) {
		// TODO - implement JobApplication.addJobApp
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jobRecID
	 * @param talentID
	 */
	public void updateJobAppStatus(int jobRecID, int talentID) {
		// TODO - implement JobApplication.updateJobAppStatus
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param talentID
	 */
	public void getJobAppByTalentID(int talentID) {
		// TODO - implement JobApplication.getJobAppByTalentID
		throw new UnsupportedOperationException();
	}

	public void getJobAppByID() {
		// TODO - implement JobApplication.getJobAppByID
		throw new UnsupportedOperationException();
	}

}