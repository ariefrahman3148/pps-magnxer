public class RegistrationManager {

	/**
	 * 
	 * @param title
	 */
	public void addCourse(String title) {
		// TODO - implement RegistrationManager.addCourse
		throw new UnsupportedOperationException();
	}

}