public class Contract {

	private int contractID;
	private int startDate;
	private int endDate;
	private int employeeID;
	private int salary;
	private int jobID;
	private int companyID;
	private int createdDate;
	private int status;
	private int lastModified;

	public void createContract() {
		// TODO - implement Contract.createContract
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param contractID
	 */
	public void updateContractStatus(int contractID) {
		// TODO - implement Contract.updateContractStatus
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param contractID
	 */
	public void printContact(int contractID) {
		// TODO - implement Contract.printContact
		throw new UnsupportedOperationException();
	}

}