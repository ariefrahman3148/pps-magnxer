public class User {

	private int userID;
	private int userName;
	private int userPassword;
	private int fName;
	private int lName;
	private int email;
	private int createdDate;
	private int lastLogin;
	private int lastUpdatedDate;
	private int active;

	/**
	 * 
	 * @param userID
	 */
	public void getUserByUserID(int userID) {
		// TODO - implement User.getUserByUserID
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param userName
	 */
	public void getUserByUserName(int userName) {
		// TODO - implement User.getUserByUserName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param userID
	 */
	public void deleteUser(int userID) {
		// TODO - implement User.deleteUser
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param userID
	 */
	public void updateUser(int userID) {
		// TODO - implement User.updateUser
		throw new UnsupportedOperationException();
	}

}