public class JobAppController {

	/**
	 * 
	 * @param jobRecID
	 * @param talentID
	 */
	public void acceptJobApp(int jobRecID, int talentID) {
		// TODO - implement JobAppController.acceptJobApp
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jobRecID
	 * @param talentID
	 */
	public void rejectJobApp(int jobRecID, int talentID) {
		// TODO - implement JobAppController.rejectJobApp
		throw new UnsupportedOperationException();
	}

}