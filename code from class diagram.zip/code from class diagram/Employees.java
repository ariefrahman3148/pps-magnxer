public class Employees extends Talent {

	private int employeeID;
	private int talentID;
	private int contractID;
	private int jobID;
	private int status;

	/**
	 * 
	 * @param jobID
	 * @param talentID
	 * @param contractID
	 */
	public void addEmployee(int jobID, int talentID, int contractID) {
		// TODO - implement Employees.addEmployee
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param employeeID
	 */
	public void updateEmployee(int employeeID) {
		// TODO - implement Employees.updateEmployee
		throw new UnsupportedOperationException();
	}

	public void getEmployee() {
		// TODO - implement Employees.getEmployee
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param employeeID
	 */
	public void getEmployeeByID(int employeeID) {
		// TODO - implement Employees.getEmployeeByID
		throw new UnsupportedOperationException();
	}

}