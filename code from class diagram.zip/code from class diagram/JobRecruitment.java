public class JobRecruitment {

	private string jobRecID;
	private int startDate;
	private int endDate;
	private int createdDate;
	private int Description;
	private int lastModified;
	private int jobID;
	private int active;

	public void createJobRecruitment() {
		// TODO - implement JobRecruitment.createJobRecruitment
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jobRecID
	 */
	public void updateJobRecruitment(int jobRecID) {
		// TODO - implement JobRecruitment.updateJobRecruitment
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jobRectID
	 */
	public void deleteJobRecruitment(int jobRectID) {
		// TODO - implement JobRecruitment.deleteJobRecruitment
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jobID
	 */
	public void getJobRecruitmentByJob(int jobID) {
		// TODO - implement JobRecruitment.getJobRecruitmentByJob
		throw new UnsupportedOperationException();
	}

	public void getActiveJobRecruitment() {
		// TODO - implement JobRecruitment.getActiveJobRecruitment
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jobRecID
	 */
	public void getJobRecByID(int jobRecID) {
		// TODO - implement JobRecruitment.getJobRecByID
		throw new UnsupportedOperationException();
	}

}