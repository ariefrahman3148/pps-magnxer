public class Authentication {

	public void login() {
		// TODO - implement Authentication.login
		throw new UnsupportedOperationException();
	}

	public void register() {
		// TODO - implement Authentication.register
		throw new UnsupportedOperationException();
	}

	public void logout() {
		// TODO - implement Authentication.logout
		throw new UnsupportedOperationException();
	}

	public void loggedIn() {
		// TODO - implement Authentication.loggedIn
		throw new UnsupportedOperationException();
	}

	public void userNameCheck() {
		// TODO - implement Authentication.userNameCheck
		throw new UnsupportedOperationException();
	}

	public void registerAsTalent() {
		// TODO - implement Authentication.registerAsTalent
		throw new UnsupportedOperationException();
	}

	public void registerAsCompany() {
		// TODO - implement Authentication.registerAsCompany
		throw new UnsupportedOperationException();
	}

	public void verifyAccount() {
		// TODO - implement Authentication.verifyAccount
		throw new UnsupportedOperationException();
	}

}