public class Report {

	private int employeeID;
	private int contractID;
	private int reportType;
	private int taxDoc;
	private int healthReportDoc;
	private int description;
	private int createdDate;
	private int year;

	public void createReport() {
		// TODO - implement Report.createReport
		throw new UnsupportedOperationException();
	}

	public void printReport() {
		// TODO - implement Report.printReport
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param employeeID
	 */
	public void getReportByEmployeeID(int employeeID) {
		// TODO - implement Report.getReportByEmployeeID
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param year
	 */
	public void getReportByYear(int year) {
		// TODO - implement Report.getReportByYear
		throw new UnsupportedOperationException();
	}

}