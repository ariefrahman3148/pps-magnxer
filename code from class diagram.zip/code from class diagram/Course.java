public class Course {
}